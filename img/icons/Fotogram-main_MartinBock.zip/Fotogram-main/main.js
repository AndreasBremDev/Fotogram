let myImgs = [
    "./img/field.jpg",
    "./img/japan.jpg",
    "./img/lake.jpg",
    "./img/mountain.jpg",
    "./img/mountain_1.jpg",
    "./img/mountains.jpg",
    "./img/sea.jpg",
    "./img/sunset.jpg",
    "./img/sunset_1.jpg",
    "./img/waterfall.jpg",
    "./img/beach.jpg",
    "./img/lake_1.jpg",
    "./img/mountain_2.jpg",
];

// all imgs are read out and packed into a variable
function render() {
    let contentRef = document.getElementById('imageContainer');
    contentRef.innerHTML = "";
    for (let i = 0; i < myImgs.length; i++) {
        contentRef.innerHTML += getImgsTemplate(i, myImgs);
    }
};

// container for all thumbnailImgs wird created and filled
function getImgsTemplate(index, myImgs) {
    return `   <span onclick="overlayOn(${index})" class="thumbnailsContainer">
                    <a>
                        <img src=${myImgs[index]}>
                    </a>
                </span>
            `;
};

// overlay aktivated
function overlayOn(index) {
    document.getElementById("overlay").style.display = "block";
    let contentRef = document.getElementById('overlay');

    // for endless loop of previews forwart and reverse
    if (index > myImgs.length - 1) {
        index = 0;
    }
    else if (index < 0) {
        index = myImgs.length - 1;
    }
    contentRef.innerHTML = createHTMLContent(index, myImgs);
};

// setInterval for diaShow
let myInterval;
function test(index) {

    myInterval = setInterval(function () {

        index += 1;
        if (index > myImgs.length - 1) {
            index = 0;
        }
        overlayOn(index);

    }, 1000);
};

// container for previews created and filled
// Path from imgs deleted
function createHTMLContent(index, myImgs) {
    return `   
                                <div onclick="logDownWithBubblingPrevention(event)" id="imgContainer">
                                    <div class="imgNaviTop">
                                        <button onclick="test(${index})">Diashow</button>
                                        
                                        ${myImgs[index].split("./img/").pop()}
                                        <h3 onclick="overlayOff()">X</h3>
                                    </div>
                                    <img src=${myImgs[index]}>
                                    <div class="imgNaviBottom">
                                        <img onclick="overlayOn(${index - 1}), myStop()" class="icons" src=./img/icons/arrows_left_red.png>
                                        <p>${index + 1} / ${myImgs.length}</p>
                                        <img onclick="overlayOn(${index + 1}),  myStop()" class="icons" src=./img/icons/arrows_right_red.png>
                                    </div>
                                </div>
                            `;
};

// stop diaShow
function myStop() {
    clearInterval(myInterval);
};

// overlay deaktivated
function overlayOff() {
    document.getElementById("overlay").style.display = "none";
    myStop();
};

// event bubbling
function logDownWithBubblingPrevention(event) {
    // console.log(logDown);
    event.stopPropagation();
};